Install eclipse in the following link https://www.eclipse.org/downloads/packages/release/neon/3/eclipse-ide-java-ee-developers;
Import the download folder in Eclipse and Download Apache tomcat zip file from https://tomcat.apache.org/download-70.
Add Jar file and set tomcat server, you can refer the following link to these actions https://www.javatpoint.com/creating-servlet-in-eclipse-ide.
Add  JDBC Driver to the project .
change the details of  mysql running in local host ,port ,username and password.
import  the sql file in your mysql workbench.
